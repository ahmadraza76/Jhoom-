#!/bin/bash

echo "Activating virtual environment..."
source ./env/bin/activate

echo "Running JhoomMusicBot..."
python3 -m jhoom.main

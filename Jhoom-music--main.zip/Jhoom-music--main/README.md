# JhoomMusicBot

An ultra-premium, scalable and modular Telegram Music Bot built with Pyrogram, PyTgCalls, yt-dlp, Spotipy, and Prometheus. Supports YouTube, Spotify, direct URLs, live streams, and more!

---

### 🚀 Features

- YouTube, Spotify & M3U8 Live Streaming
- Audio & Video playback with queue system
- Inline Search Results
- Persistent SQLite Queue
- FFmpeg Streaming with pause/resume/skip
- Prometheus Monitoring Support
- Modular, SaaS-Ready Architecture

---

### 📦 Requirements

- Python 3.9+
- FFmpeg Installed
- Telegram Bot Token, API ID & Hash
- Spotify Client ID & Secret (for `/play spotify`)

---

### ⚙️ Environment Variables

| Variable             | Description                        |
|----------------------|------------------------------------|
| `API_ID`             | Telegram API ID                    |
| `API_HASH`           | Telegram API HASH                  |
| `BOT_TOKEN`          | Telegram Bot Token                 |
| `SPOTIFY_CLIENT_ID`  | Spotify Developer Client ID        |
| `SPOTIFY_CLIENT_SECRET` | Spotify Client Secret          |
| `FFMPEG_PROCESSES`   | Number of concurrent FFmpeg jobs   |
| `MAX_DURATION`       | Max track duration (in seconds)    |
| `MAX_QUEUE_SIZE`     | Queue limit per group              |

---

### ▶️ How to Run

```bash
git clone https://github.com/yourusername/JhoomMusicBot
cd JhoomMusicBot

python3 -m venv env
source env/bin/activate

pip install -r requirements.txt

export API_ID=...
export API_HASH=...
export BOT_TOKEN=...
export SPOTIFY_CLIENT_ID=...
export SPOTIFY_CLIENT_SECRET=...

python3 -m jhoom.main# Jhoom-music-

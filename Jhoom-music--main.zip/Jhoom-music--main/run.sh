#!/bin/bash

clear
echo "🔁 Pulling latest changes..."
git pull

echo "⚙️ Restarting bot..."
pkill -f "jhoom.main" || true

sleep 1
nohup python3 -m jhoom.main > logs.txt 2>&1 &
echo "✅ Bot started in background. Check logs with: tail -f logs.txt"

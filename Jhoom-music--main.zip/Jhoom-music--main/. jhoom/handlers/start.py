from pyrogram import Client, filters
from pyrogram.types import Message
from jhoom.ui.main_menu import main_menu_ui
from jhoom.core.metrics import commands_processed
from jhoom.config import MAIN_MENU_IMG

@Client.on_message(filters.command("start"))
async def start_command(client: Client, message: Message):
    commands_processed.labels(command='start').inc()
    text, buttons = main_menu_ui()
    await message.reply_photo(
        photo=MAIN_MENU_IMG,
        caption=text,
        reply_markup=buttons
    )

from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton

def help_menu_ui():
    text = """📖 **Help Menu**

Here are available commands:

• `/play` - Play music/audio
• `/vplay` - Play video
• `/pause` - Pause playback
• `/resume` - Resume playback
• `/skip` - Next track
• `/stop` - Stop and clear queue
• `/queue` - Show current queue
• `/health` - Check system health
"""

    buttons = InlineKeyboardMarkup([
        [InlineKeyboardButton("🔙 Back", callback_data="main_menu")]
    ])
    return text, buttons

from datetime import datetime
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton

def main_menu_ui():
    current_time = datetime.now().strftime("%H:%M:%S")
    text = f"""
🎵 **Jhoom Music Bot** 🎵

⚡ Experience Ultra-premium Music
⏰ Time: `{current_time}`
"""

    buttons = InlineKeyboardMarkup([
        [InlineKeyboardButton("➕ Add to Group", url="https://t.me/JhoomMusicBot?startgroup=true")],
        [InlineKeyboardButton("ℹ️ Help", callback_data="help_menu")],
        [InlineKeyboardButton("⚙️ Settings", callback_data="system_menu"),
         InlineKeyboardButton("👨‍💻 Developer", callback_data="dev_info")]
    ])
    return text, buttons

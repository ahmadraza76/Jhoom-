import logging
from spotipy import Spotify
from spotipy.oauth2 import SpotifyClientCredentials
from jhoom.config import SPOTIFY_CLIENT_ID, SPOTIFY_CLIENT_SECRET
from jhoom.core.stream_controller import StreamController

logger = logging.getLogger(__name__)

class MusicBot:
    def __init__(self, app, pytgcalls):
        self.app = app
        self.pytgcalls = pytgcalls
        self.stream_controller = StreamController(pytgcalls)

        self.spotify = Spotify(
            auth_manager=SpotifyClientCredentials(
                client_id=SPOTIFY_CLIENT_ID,
                client_secret=SPOTIFY_CLIENT_SECRET
            )
        )

    async def initialize(self):
        await self.stream_controller.init_db()

    async def cleanup(self):
        for chat_id in list(self.stream_controller.current_streams.keys()):
            try:
                await self.pytgcalls.leave_group_call(chat_id)
            except Exception:
                pass
        self.stream_controller.current_streams.clear()
        self.stream_controller.queues.clear()

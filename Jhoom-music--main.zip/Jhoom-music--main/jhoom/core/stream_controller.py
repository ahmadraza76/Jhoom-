import asyncio
import json
import aiosqlite
import logging
from typing import Dict, List, Optional
from jhoom.config import NOW_PLAYING_IMG, ERROR_IMG, MAX_QUEUE_SIZE
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from pytgcalls.types import AudioPiped, VideoPiped
from pytgcalls.types.input_stream.quality import HighQualityAudio, HighQualityVideo
from jhoom import app

logger = logging.getLogger(__name__)

class StreamController:
    def __init__(self, pytgcalls):
        self.pytgcalls = pytgcalls
        self.current_streams: Dict[int, dict] = {}
        self.queues: Dict[int, List[dict]] = {}
        self.paused_streams: Dict[int, bool] = {}
        self.search_results: Dict[int, List[dict]] = {}
        self.db_lock = asyncio.Lock()
        self.stream_lock = asyncio.Lock()

    async def init_db(self):
        async with aiosqlite.connect('jhoom.db') as conn:
            await conn.execute('''CREATE TABLE IF NOT EXISTS queues
                                  (chat_id INTEGER, track_data TEXT, position INTEGER)''')
            await conn.commit()

    async def save_queue(self, chat_id: int):
        async with self.db_lock:
            async with aiosqlite.connect('jhoom.db') as conn:
                await conn.execute('DELETE FROM queues WHERE chat_id = ?', (chat_id,))
                for pos, track in enumerate(self.queues.get(chat_id, [])):
                    await conn.execute(
                        'INSERT INTO queues (chat_id, track_data, position) VALUES (?, ?, ?)',
                        (chat_id, json.dumps(track), pos)
                    )
                await conn.commit()

    async def restore_queue(self, chat_id: int):
        async with self.db_lock:
            async with aiosqlite.connect('jhoom.db') as conn:
                cursor = await conn.execute(
                    'SELECT track_data FROM queues WHERE chat_id = ? ORDER BY position', (chat_id,)
                )
                rows = await cursor.fetchall()
                self.queues[chat_id] = [json.loads(row[0]) for row in rows]
                await cursor.close()

    async def play_next(self, chat_id: int):
        async with self.stream_lock:
            if chat_id in self.queues and self.queues[chat_id]:
                track = self.queues[chat_id].pop(0)
                self.current_streams[chat_id] = track
                await self.save_queue(chat_id)

                try:
                    await self.start_stream(chat_id, track)
                except Exception as e:
                    logger.error(f"Error playing next: {e}")
                    await app.send_message(chat_id, f"❌ Error: {e}")
                    await self.play_next(chat_id)
            else:
                await self.stop_stream(chat_id)

    async def start_stream(self, chat_id: int, track: dict):
        if track.get("video"):
            await self.pytgcalls.change_stream(
                chat_id, VideoPiped(track["url"], HighQualityVideo())
            )
        else:
            await self.pytgcalls.change_stream(
                chat_id, AudioPiped(track["url"], HighQualityAudio(), **track.get("ffmpeg_options", {}))
            )
        await app.send_photo(
            chat_id,
            photo=track.get("thumbnail", NOW_PLAYING_IMG),
            caption=f"🎶 Now Playing: **{track['title']}**",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("⏸ Pause", callback_data="pause"),
                 InlineKeyboardButton("⏭ Skip", callback_data="skip")],
                [InlineKeyboardButton("⏹ Stop", callback_data="stop")]
            ])
        )

    async def stop_stream(self, chat_id: int):
        try:
            await self.pytgcalls.leave_group_call(chat_id)
        except Exception as e:
            logger.warning(f"Leave error: {e}")
        self.current_streams.pop(chat_id, None)
        self.queues.pop(chat_id, None)
        self.paused_streams.pop(chat_id, None)

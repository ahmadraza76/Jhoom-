from prometheus_client import Counter, Gauge

commands_processed = Counter('bot_commands_processed', 'Total commands processed', ['command'])
active_streams = Gauge('bot_active_streams', 'Number of active streams')
queue_size = Gauge('bot_queue_size', 'Number of tracks in queue', ['chat_id'])

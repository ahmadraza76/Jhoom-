import os

API_ID = int(os.getenv("API_ID", 0))
API_HASH = os.getenv("API_HASH", "")
BOT_TOKEN = os.getenv("BOT_TOKEN", "")

SPOTIFY_CLIENT_ID = os.getenv("SPOTIFY_CLIENT_ID", "")
SPOTIFY_CLIENT_SECRET = os.getenv("SPOTIFY_CLIENT_SECRET", "")

FFMPEG_PROCESSES = int(os.getenv("FFMPEG_PROCESSES", 1))
MAX_DURATION = int(os.getenv("MAX_DURATION", 3600))
MAX_QUEUE_SIZE = int(os.getenv("MAX_QUEUE_SIZE", 50))
CACHE_SIZE = int(os.getenv("CACHE_SIZE", 1000))

IMAGE_BASE = "https://cdn.jhoom.io/"
IMAGE_FALLBACK = "https://i.imgur.com/4M34hi2.jpg"

MAIN_MENU_IMG = os.getenv("MAIN_MENU_IMG", IMAGE_BASE + "main_menu_holo.jpg") or IMAGE_FALLBACK
HELP_IMG = os.getenv("HELP_IMG", IMAGE_BASE + "help_holo.jpg") or IMAGE_FALLBACK
SYSTEM_IMG = os.getenv("SYSTEM_IMG", IMAGE_BASE + "system_holo.jpg") or IMAGE_FALLBACK
DEV_IMG = os.getenv("DEV_IMG", IMAGE_BASE + "dev_holo.jpg") or IMAGE_FALLBACK
NOW_PLAYING_IMG = os.getenv("NOW_PLAYING_IMG", IMAGE_BASE + "now_playing_holo.jpg") or IMAGE_FALLBACK
SEARCH_IMG = os.getenv("SEARCH_IMG", IMAGE_BASE + "search_holo.jpg") or IMAGE_FALLBACK
QUEUE_IMG = os.getenv("QUEUE_IMG", IMAGE_BASE + "queue_holo.jpg") or IMAGE_FALLBACK
LIVE_IMG = os.getenv("LIVE_IMG", IMAGE_BASE + "live_holo.jpg") or IMAGE_FALLBACK
ERROR_IMG = os.getenv("ERROR_IMG", IMAGE_BASE + "error_holo.jpg") or IMAGE_FALLBACK

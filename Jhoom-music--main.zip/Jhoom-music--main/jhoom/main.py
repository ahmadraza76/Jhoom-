import asyncio
import logging
from jhoom import app, pytgcalls
from jhoom.core.stream_controller import StreamController
from jhoom.config import MAX_DURATION
from jhoom.core.bot import MusicBot

logging.basicConfig(level=logging.INFO)

async def main():
    logging.info("Starting bot...")
    music_bot = MusicBot(app, pytgcalls)
    await music_bot.initialize()

    await app.start()
    await pytgcalls.start()
    logging.info("Bot started successfully.")

    try:
        await asyncio.Event().wait()
    except KeyboardInterrupt:
        logging.info("Shutting down...")
        await music_bot.cleanup()
        await app.stop()

if __name__ == "__main__":
    asyncio.run(main())

from pyrogram import Client
from pytgcalls import PyTgCalls
from jhoom.config import API_ID, API_HASH, BOT_TOKEN, FFMPEG_PROCESSES

app = Client("JhoomBot", api_id=API_ID, api_hash=API_HASH, bot_token=BOT_TOKEN)

pytgcalls = PyTgCalls(
    app,
    cache_duration=100,
    overload_quiet_mode=True,
    multi_threading=FFMPEG_PROCESSES > 1
)

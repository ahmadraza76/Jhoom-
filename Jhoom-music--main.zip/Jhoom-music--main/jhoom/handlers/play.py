from pyrogram import Client, filters
from pyrogram.types import Message
from jhoom.config import ERROR_IMG, HELP_IMG
from jhoom.core.metrics import commands_processed
from jhoom import app
from jhoom.core.utils import format_duration

@Client.on_message(filters.command(["play", "p"]) & filters.group)
async def play_command(client: Client, message: Message):
    commands_processed.labels(command="play").inc()

    if len(message.command) < 2:
        await message.reply_photo(
            photo=HELP_IMG,
            caption="Usage: `/play song name or link`"
        )
        return

    query = " ".join(message.command[1:])
    chat_id = message.chat.id
    await app.stream_controller.restore_queue(chat_id)

    # TODO: Search and extract track info using YouTube/Spotify
    # Simulate dummy track for now
    track = {
        "title": query,
        "url": "https://example.com/audio.mp3",
        "thumbnail": "https://i.imgur.com/4M34hi2.jpg",
        "duration": 180,
        "video": False
    }

    if chat_id in app.stream_controller.current_streams:
        app.stream_controller.queues.setdefault(chat_id, []).append(track)
        await app.stream_controller.save_queue(chat_id)
        await message.reply_photo(
            photo=track["thumbnail"],
            caption=f"➕ Added to queue: **{track['title']}** ({await format_duration(track['duration'])})"
        )
    else:
        app.stream_controller.current_streams[chat_id] = track
        await app.stream_controller.start_stream(chat_id, track)

from pyrogram import Client, filters
from pyrogram.types import Message
from jhoom.config import HELP_IMG
from jhoom.core.metrics import commands_processed
from jhoom import app

@Client.on_message(filters.command(["vplay", "vp"]) & filters.group)
async def vplay_command(client: Client, message: Message):
    commands_processed.labels(command='vplay').inc()

    if len(message.command) < 2:
        await message.reply_photo(photo=HELP_IMG, caption="Usage: `/vplay video name or link`")
        return

    query = " ".join(message.command[1:])
    chat_id = message.chat.id
    await app.stream_controller.restore_queue(chat_id)

    track = {
        "title": query,
        "url": "https://example.com/video.mp4",
        "thumbnail": "https://i.imgur.com/4M34hi2.jpg",
        "duration": 240,
        "video": True
    }

    if chat_id in app.stream_controller.current_streams:
        app.stream_controller.queues.setdefault(chat_id, []).append(track)
        await app.stream_controller.save_queue(chat_id)
        await message.reply_photo(
            photo=track["thumbnail"],
            caption=f"➕ Queued: **{track['title']}**"
        )
    else:
        app.stream_controller.current_streams[chat_id] = track
        await app.stream_controller.start_stream(chat_id, track)

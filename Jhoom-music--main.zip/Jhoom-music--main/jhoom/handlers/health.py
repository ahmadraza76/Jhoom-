from pyrogram import Client, filters
from pyrogram.types import Message
from jhoom.config import SYSTEM_IMG
from jhoom.core.metrics import commands_processed
from jhoom import app
import json
import os

@Client.on_message(filters.command("health") & filters.group)
async def health_command(client: Client, message: Message):
    commands_processed.labels(command='health').inc()
    stats = {
        "streams": len(app.stream_controller.current_streams),
        "queued": sum(len(q) for q in app.stream_controller.queues.values()),
        "paused": len(app.stream_controller.paused_streams),
        "pid": os.getpid()
    }
    await message.reply_photo(
        photo=SYSTEM_IMG,
        caption=f"🩺 **Health Check:**\n\n`{json.dumps(stats, indent=2)}`"
    )

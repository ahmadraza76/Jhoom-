from pyrogram import Client, filters
from pyrogram.types import Message
from jhoom.core.metrics import commands_processed
from jhoom.config import QUEUE_IMG
from jhoom.core.utils import format_duration
from jhoom import app

@Client.on_message(filters.command("queue") & filters.group)
async def queue_command(client: Client, message: Message):
    commands_processed.labels(command='queue').inc()
    chat_id = message.chat.id

    await app.stream_controller.restore_queue(chat_id)
    queue = app.stream_controller.queues.get(chat_id, [])

    if not queue:
        await message.reply_photo(photo=QUEUE_IMG, caption="❗ Queue is empty.")
        return

    text = "📋 **Queue:**\n\n"
    for i, track in enumerate(queue[:10], start=1):
        duration = await format_duration(track["duration"]) if not track.get("is_live") else "Live"
        text += f"{i}. {track['title']} ({duration})\n"

    if len(queue) > 10:
        text += f"\n...and {len(queue) - 10} more."

    await message.reply_photo(photo=QUEUE_IMG, caption=text)

from pyrogram import Client, filters
from pyrogram.types import Message
from jhoom.core.metrics import commands_processed
from jhoom.config import NOW_PLAYING_IMG, ERROR_IMG
from jhoom import app
import aiosqlite

@Client.on_message(filters.command("stop") & filters.group)
async def stop_command(client: Client, message: Message):
    commands_processed.labels(command='stop').inc()
    chat_id = message.chat.id

    if chat_id in app.stream_controller.current_streams:
        await app.pytgcalls.leave_group_call(chat_id)
        async with app.stream_controller.db_lock:
            app.stream_controller.current_streams.pop(chat_id, None)
            app.stream_controller.queues.pop(chat_id, None)
            app.stream_controller.paused_streams.pop(chat_id, None)

            async with aiosqlite.connect("jhoom.db") as conn:
                await conn.execute("DELETE FROM queues WHERE chat_id = ?", (chat_id,))
                await conn.commit()

        await message.reply_photo(photo=NOW_PLAYING_IMG, caption="⏹ Playback stopped.")
    else:
        await message.reply_photo(photo=ERROR_IMG, caption="Nothing to stop.")

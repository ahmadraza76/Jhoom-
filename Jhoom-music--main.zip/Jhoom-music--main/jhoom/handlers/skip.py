from pyrogram import Client, filters
from pyrogram.types import Message
from jhoom.core.metrics import commands_processed
from jhoom.config import NOW_PLAYING_IMG, ERROR_IMG
from jhoom import app

@Client.on_message(filters.command("skip") & filters.group)
async def skip_command(client: Client, message: Message):
    commands_processed.labels(command='skip').inc()
    chat_id = message.chat.id

    if chat_id in app.stream_controller.current_streams:
        await app.stream_controller.play_next(chat_id)
        await message.reply_photo(photo=NOW_PLAYING_IMG, caption="⏭ Skipped to next track.")
    else:
        await message.reply_photo(photo=ERROR_IMG, caption="Nothing to skip.")

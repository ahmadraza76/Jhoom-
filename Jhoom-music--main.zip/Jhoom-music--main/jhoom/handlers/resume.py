from pyrogram import Client, filters
from pyrogram.types import Message
from jhoom.core.metrics import commands_processed
from jhoom.config import NOW_PLAYING_IMG, ERROR_IMG
from jhoom import app

@Client.on_message(filters.command("resume") & filters.group)
async def resume_command(client: Client, message: Message):
    commands_processed.labels(command='resume').inc()
    chat_id = message.chat.id

    if chat_id in app.stream_controller.current_streams:
        if chat_id in app.stream_controller.paused_streams:
            await app.pytgcalls.resume_stream(chat_id)
            del app.stream_controller.paused_streams[chat_id]
            await message.reply_photo(photo=NOW_PLAYING_IMG, caption="▶️ Resumed.")
        else:
            await message.reply_photo(photo=ERROR_IMG, caption="Playback not paused.")
    else:
        await message.reply_photo(photo=ERROR_IMG, caption="Nothing is playing.")

from pyrogram import Client, filters
from pyrogram.types import Message
from jhoom.core.metrics import commands_processed
from jhoom.config import NOW_PLAYING_IMG, ERROR_IMG
from jhoom import app

@Client.on_message(filters.command("pause") & filters.group)
async def pause_command(client: Client, message: Message):
    commands_processed.labels(command='pause').inc()
    chat_id = message.chat.id

    if chat_id in app.stream_controller.current_streams:
        if chat_id not in app.stream_controller.paused_streams:
            await app.pytgcalls.pause_stream(chat_id)
            app.stream_controller.paused_streams[chat_id] = True
            await message.reply_photo(photo=NOW_PLAYING_IMG, caption="⏸ Playback paused.")
        else:
            await message.reply_photo(photo=ERROR_IMG, caption="Already paused.")
    else:
        await message.reply_photo(photo=ERROR_IMG, caption="Nothing is playing.")

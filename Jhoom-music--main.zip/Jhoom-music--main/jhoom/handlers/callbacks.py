from pyrogram import Client, filters
from pyrogram.types import CallbackQuery, InputMediaPhoto
from jhoom.ui.main_menu import main_menu_ui
from jhoom.ui.help_menu import help_menu_ui
from jhoom.config import MAIN_MENU_IMG, HELP_IMG, SYSTEM_IMG, DEV_IMG

@Client.on_callback_query(filters.regex("^main_menu$"))
async def main_menu_callback(client: Client, callback: CallbackQuery):
    text, buttons = main_menu_ui()
    await callback.message.edit_media(
        media=InputMediaPhoto(media=MAIN_MENU_IMG, caption=text),
        reply_markup=buttons
    )
    await callback.answer()

@Client.on_callback_query(filters.regex("^help_menu$"))
async def help_menu_callback(client: Client, callback: CallbackQuery):
    text, buttons = help_menu_ui()
    await callback.message.edit_media(
        media=InputMediaPhoto(media=HELP_IMG, caption=text),
        reply_markup=buttons
    )
    await callback.answer()

@Client.on_callback_query(filters.regex("^system_menu$"))
async def system_menu(client: Client, callback: CallbackQuery):
    text = f"""⚙️ **System Menu**

🔊 Streams: {len(app.stream_controller.current_streams)}
📋 Queue Items: {sum(len(q) for q in app.stream_controller.queues.values())}
⏸ Paused: {len(app.stream_controller.paused_streams)}
"""
    await callback.message.edit_media(
        media=InputMediaPhoto(media=SYSTEM_IMG, caption=text),
        reply_markup=callback.message.reply_markup
    )
    await callback.answer()

@Client.on_callback_query(filters.regex("^dev_info$"))
async def dev_info(client: Client, callback: CallbackQuery):
    text = """👨‍💻 **Developer Info**

Bot: JhoomMusic
Version: v1.0
Team: Apple Music India
"""
    await callback.message.edit_media(
        media=InputMediaPhoto(media=DEV_IMG, caption=text),
        reply_markup=callback.message.reply_markup
    )
    await callback.answer()
